import React from "react";
import Slideshow from "./slideshow.component";
import './home.css'

export default() => {
      
        return (
        <div className="auth-inner">
                <Slideshow />
                <h3>Logged In</h3>
                </div>
        );
    
}
